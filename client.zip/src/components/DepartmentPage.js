import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const DepartmentPage = () => {
  const [departments, setDepartments] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:3000/departments")
      .then((response) => {
        setDepartments(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  return (
    <div>
      <h1>Departments</h1>
      <ul>
        {departments.map((department) => (
          <li key={department.id}>
            <Link to={`/departments/${department.id}/semesters`}>
              {department.name}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default DepartmentPage;