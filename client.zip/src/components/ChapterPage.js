import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

const ChapterPage = () => {
  const { departmentId, semesterId, subjectId } = useParams();
  const [chapters, setChapters] = useState([]);

  useEffect(() => {
    axios
      .get(
        `http://localhost:3000/departments/${departmentId}/semesters/${semesterId}/subjects/${subjectId}/chapters`
      )
      .then((response) => {
        setChapters(response.data);
      });
  }, [departmentId, semesterId, subjectId]);

  return (
    <div>
      <>
        <h1>Chapters</h1>
        <ul>
          {chapters.map((chapter) => (
            <li key={chapter.id}>
              <h3>{chapter.title}</h3>
              <p>{chapter.description}</p>
            </li>
          ))}
        </ul>
      </>
    </div>
  );
};

export default ChapterPage;
