import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import DepartmentPage from "./components/DepartmentPage";
import SemesterPage from "./components/SemesterPage";
import SubjectPage from "./components/SubjectPage";
import ChapterPage from "./components/ChapterPage";

const App = () => {
  return (
    <Router>
      <div className="App">
        {/* <Navbar /> */}
        <Routes>
          <Route path="/departments" element={<DepartmentPage />} />
          <Route
            path="/departments/:departmentId/semesters"
            element={<SemesterPage />}
          />
          <Route
            path="/departments/:departmentId/semesters/:semesterId/subjects"
            element={<SubjectPage />}
          />
          <Route
            path="/departments/:departmentId/semesters/:semesterId/subjects/:subjectId/chapters"
            element={<ChapterPage />}
          />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
